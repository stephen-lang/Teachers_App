// ignore: constant_identifier_names
const String  GEMINI_API_KEY= "AIzaSyCV0aSaj2mReEG6bHmIK5eU41DpTIQkbwk";