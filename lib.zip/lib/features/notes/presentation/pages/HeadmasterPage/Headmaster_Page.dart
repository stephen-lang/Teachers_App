import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

import '../../../../../core/common/entities/user.dart';
import '../../../../auth/presentation/bloc/auth_bloc.dart';
import '../../../../auth/presentation/pages/WelcomeScreen.dart';
import '../../bloc/school/school_bloc.dart';
import '../../bloc/school/school_state.dart';
import '../../bloc/school/school_event.dart';

class HeadmasterDashboard extends StatelessWidget {
  final AppUser user;

  const HeadmasterDashboard({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) {
        final bloc = SchoolBloc(getSchoolById: GetIt.I());
        bloc.add(SchoolFetchByIdRequested(schoolId: user.schoolId!));
        return bloc;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Headmaster Dashboard"),
          backgroundColor: Colors.blue.shade700,
          foregroundColor: Colors.white,
          actions: [
            IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: () {
                context.read<AuthBloc>().add(AuthSignOut());
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const WelcomeScreen()),
                );
              },
            ),
          ],
        ),
        body: BlocBuilder<SchoolBloc, SchoolState>(
          builder: (context, state) {
            if (state is SchoolLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is SchoolLoadByIdSuccess) {
              final school = state.school;

              // Placeholder data for now — will replace with Firestore data
              int totalTeachers = 8;
              int totalNotes = 25;
              int pendingNotes = 4;
              List<Map<String, dynamic>> teachers = [
                {"name": "John Doe", "email": "john@example.com", "notesCount": 5},
                {"name": "Jane Smith", "email": "jane@example.com", "notesCount": 3},
              ];
              List<Map<String, dynamic>> recentNotes = [
                {"strand": "Math - Fractions", "teacherName": "John Doe", "status": "Pending"},
                {"strand": "English - Grammar", "teacherName": "Jane Smith", "status": "Approved"},
              ];

              return RefreshIndicator(
                onRefresh: () async {
                  context.read<SchoolBloc>().add(
                        SchoolFetchByIdRequested(schoolId: user.schoolId!),
                      );
                },
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Welcome
                      Text(
                        "Welcome, ${user.displayName}",
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      const Text("Your School ID:", style: TextStyle(fontSize: 16)),
                      SelectableText(
                        user.schoolId!,
                        style: const TextStyle(fontSize: 16, color: Colors.blue),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "School Name: ${school.schoolName}",
                        style: const TextStyle(fontSize: 16),
                      ),
                      const Divider(height: 30, thickness: 1),

                      // Stats Section
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatCard("Teachers", totalTeachers),
                          _buildStatCard("Lesson Notes", totalNotes),
                          _buildStatCard("Pending Notes", pendingNotes),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // Teachers List
                      const Text(
                        "Teachers",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ...teachers.map((t) => ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(t["name"]),
                            subtitle: Text(t["email"]),
                            trailing: Text("${t["notesCount"]} notes"),
                          )),

                      const Divider(height: 30, thickness: 1),

                      // Recent Lesson Notes
                      const Text(
                        "Recent Lesson Notes",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ...recentNotes.map((note) => ListTile(
                            leading: const Icon(Icons.note),
                            title: Text(note["strand"]),
                            subtitle: Text("By ${note["teacherName"]}"),
                            trailing: Text(note["status"]),
                          )),

                      const Divider(height: 30, thickness: 1),

                      // Search Box
                      const Text(
                        "Teacher Search",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        decoration: InputDecoration(
                          hintText: "Search by name or subject",
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Export Report
                      ElevatedButton.icon(
                        icon: const Icon(Icons.picture_as_pdf),
                        onPressed: () {
                          // TODO: Add export functionality
                        },
                        label: const Text("Export Report"),
                      ),
                    ],
                  ),
                ),
              );
            } else if (state is SchoolFailure) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(state.message),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {
                        context.read<SchoolBloc>().add(
                              SchoolFetchByIdRequested(schoolId: user.schoolId!),
                            );
                      },
                      child: const Text("Retry"),
                    )
                  ],
                ),
              );
            }

            return const SizedBox.shrink();
          },
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, int value) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              "$value",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text(title),
          ],
        ),
      ),
    );
  }
}
