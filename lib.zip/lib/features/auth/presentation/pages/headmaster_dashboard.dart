import 'package:flutter/material.dart';

class HeadmasterDashboard extends StatelessWidget {
  const HeadmasterDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Headmaster Dashboard')),
      body: const Center(
        child: Text('Welcome, Headmaster!'),
      ),
    );
  }
}
