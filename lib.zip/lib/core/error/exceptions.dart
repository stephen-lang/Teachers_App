class ServerException implements Exception {
    final message;

  const ServerException({  
       required this.message});
}