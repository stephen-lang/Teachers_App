class Failure {
  final String message;

  Failure({  this.message="An Unexpected error has occured"});
}