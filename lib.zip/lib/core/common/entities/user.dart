// user entity
 
class User {
  final String displayName ;
  final String email;
  final String uid;
  final String role;

   

  User( {required this.displayName , required this.email, required this.uid ,required this.role});

 
   
}

